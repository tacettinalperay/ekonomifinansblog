
TACETTIN ALPER AY - BLOG (STATIK)

Klasörü açın ve index.html dosyasına çift tıklayın.
İçerik eklemek için ilgili sayfayı (.html) Not Defteri veya VS Code ile açın.
<h1>, <h2>, <p>, <ul><li> bloklarını kendinize göre düzenleyin.

Sayfalar:
- index.html (ana sayfa)
- finans.html
- enerji.html
- devlet-yardimlari.html
- resmi-gazete.html
- ilgili-kanunlar.html
